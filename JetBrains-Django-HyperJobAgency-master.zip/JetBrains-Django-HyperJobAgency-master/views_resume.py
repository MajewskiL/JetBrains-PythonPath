from django.shortcuts import render
from django.views.generic import TemplateView
from resume.models import Resume
from django.shortcuts import redirect
from django.core.exceptions import PermissionDenied

# Create your views here.
class ResumeView(TemplateView):
    template_name = 'resume/resumes.html'

    def get(self, request, *args, **kwargs):
        res_list = Resume.objects.all()
        return render(request, self.template_name, {"lista":res_list})

class CreateResumeView(TemplateView):
    template_name = 'resume/new.html'
    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            if request.user.is_staff:
                raise PermissionDenied
            else:
                Resume.objects.create(author=request.user, description=request.POST['description'])
                return redirect("/home")


