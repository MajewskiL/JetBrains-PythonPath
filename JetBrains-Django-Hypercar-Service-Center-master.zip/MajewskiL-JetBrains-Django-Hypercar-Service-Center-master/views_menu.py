from django.views import View
from django.shortcuts import render
from django.views.generic.base import TemplateView
from collections import deque
from django.shortcuts import redirect

bilet = 0
blok = [
    {"name" : "change_oil", "link":"Change oil", "czas":2, "prio": 0},
    {"name" : "inflate_tires", "link":"Inflate tires", "czas":5, "prio": 1},
    {"name" : "diagnostic", "link": "Get diagnostic test", "czas":30, "prio": 2},
]
kolejka = [deque([]) for x in range(len(blok))]
czas = [2,5,30]
ostatni = 0

class MenuView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'menu/index.html', context={"blok":blok})

class QueueView(TemplateView):
    template_name = 'menu/kolejka.html'

    def get_context_data(self, **kwargs):
        global bilet
        context = super().get_context_data(**kwargs)
        n_name = kwargs['n_name']
        context['ile'] = 0
        for nm in blok:
            if nm["name"] == n_name:
                bilet += 1
                for x in range(nm["prio"] + 1):
                    context['ile'] += len(kolejka[x]) * czas[x]
                kolejka[nm["prio"]].append(bilet)
                context['kolej'] = bilet
                break
        return context

class ProcesView(TemplateView):
    def get(self, request, *args, **kwargs):
        context = {}
        for x in blok:
            context["x" + str(x["prio"])] = len(kolejka[x["prio"]])
        for x in kolejka:
            if len(x) != 0:
                context["nastepny"] = x[0]
                break
        context["all"] = kolejka
        return render(request, 'menu/processing.html', context=context)

    def post(self, request, *args, **kwargs):
        global ostatni
        context = {}
        for x in kolejka:
            if len(x) != 0:
                ostatni = x.popleft()
                break
        return redirect('/next')

class NextView(TemplateView):
   def get(self, request, *args, **kwargs):
        global ostatni
        context = {}
        context["nastepny"] = ostatni
        return render(request, 'menu/next.html', context=context)


