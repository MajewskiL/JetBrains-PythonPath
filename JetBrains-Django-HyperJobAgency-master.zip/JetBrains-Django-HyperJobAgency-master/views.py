from django.shortcuts import render
from django.views.generic import TemplateView
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.views.generic import CreateView
from django.contrib.auth.views import LoginView
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

class MenuView(TemplateView):
    template_name = 'menu/index.html'
    def get(self, request, *args, **kwargs):
        context= {"user":request.user}
        return render(request, self.template_name, context=context)

class ProfileView(TemplateView):
    template_name = 'menu/profile.html'
    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

class MojLoginView(LoginView):
    redirect_authenticated_user = True
    template_name = 'menu/login.html'
    form_class = AuthenticationForm

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, {'form':self.form_class})

    def post(self, request, *args, **kwargs):
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("/profile")
        else:
            return redirect("/login")

class SignupView(CreateView):
    form_class = UserCreationForm
    success_url = 'home'
    template_name = 'menu/signup.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, {'form':self.form_class})

    def post(self, request, *args, **kwargs):
        username = request.POST['username']
        password = request.POST['password1']
        user = User.objects.create_user(username, None, password)#, is_staff=True)
        user.save()
        return redirect("/login")

