from django.shortcuts import render
from django.views.generic import TemplateView
from vacancy.models import Vacancy
from django.shortcuts import redirect
from django.core.exceptions import PermissionDenied

class VacancyView(TemplateView):
    template_name = 'vacancy/vacancy.html'

    def get(self, request, *args, **kwargs):
        vac_list = Vacancy.objects.all()
        return render(request, self.template_name, {"lista":vac_list})

class CreateVacanceView(TemplateView):
    template_name = 'vacancy/new.html'
    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            if not request.user.is_staff:
                raise PermissionDenied
            else:
                Vacancy.objects.create(author=request.user, description=request.POST['description'])
                return redirect("/home")
